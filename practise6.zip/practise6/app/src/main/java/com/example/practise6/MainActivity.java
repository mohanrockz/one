package com.example.practise6;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.net.URI;

public class MainActivity extends AppCompatActivity {

    EditText text1;
    Button btn;
    String s="";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        text1 = findViewById(R.id.editTextTextPersonName);
        btn = findViewById(R.id.button);



        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    SmsManager smsManager=  SmsManager.getDefault();
                    smsManager.sendTextMessage(text1.getText().toString(),null,text1.getText().toString(),null, null);
                    Toast.makeText(MainActivity.this, "SMS SENT SUCCESSFULLY", Toast.LENGTH_SHORT).show();
                }catch (Exception e){
                    Toast.makeText(MainActivity.this, "SMS FAILED", Toast.LENGTH_SHORT).show();
                }
            }
        });


        text1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                s=text1.getText().toString();
                Intent intent= new Intent(Intent.ACTION_SENDTO, Uri.parse("sms:" +s));
                startActivity(intent);
            }
        });
    }
}




