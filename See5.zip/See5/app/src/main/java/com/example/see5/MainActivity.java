package com.example.see5;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;


public class MainActivity extends AppCompatActivity {

    Button btn1,btn2;
    EditText user,pass;
    DBHelper dbh;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btn1 = findViewById(R.id.button);
        btn2=findViewById(R.id.button2);
        user = findViewById(R.id.user1);
        pass = findViewById(R.id.password);


        dbh = new DBHelper(this);

        btn1.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                Boolean res = dbh.validate(user.getText().toString(), pass.getText().toString());
                if (res) {
                    String Users=user.getText().toString();
                    Intent intent = new Intent(MainActivity.this, MainActivity2.class);
                    intent.putExtra("username",Users);
                    startActivity(intent);
                } else {
                    Toast.makeText(getApplicationContext(), "wrong id or password", Toast.LENGTH_SHORT).show();
                }

            }
        });

        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Boolean res = dbh.Register(user.getText().toString(), pass.getText().toString());

                if (res) {
                    Toast.makeText(getApplicationContext(), "USER CREATED NOW LOGIN", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(getApplicationContext(), "USER ALREADY EXIT", Toast.LENGTH_SHORT).show();
                }

            }
        });

    }
}