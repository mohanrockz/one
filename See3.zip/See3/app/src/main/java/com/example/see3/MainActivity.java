package com.example.see3;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.os.Bundle;
import android.view.View;


public class MainActivity extends AppCompatActivity {

    Fragment f1;
    Fragment2 f2;
    Fragment f3;
    int curr = 0;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        f1 = new Fragment1();
        f2 = new Fragment2();
        f3 = new Fragment3();


        FragmentManager fm = getSupportFragmentManager();
        FragmentTransaction ft = fm.beginTransaction();
        ft.add(R.id.lay, f1);
        ft.commit();
        curr = 1;
    }

    public void Verify(View v) {
        FragmentManager fm = getSupportFragmentManager();
        FragmentTransaction ft = fm.beginTransaction();
        if (curr == 1) {
            ft.replace(R.id.lay, f2);
            curr=2;
        } else if (curr == 2) {
            ft.replace(R.id.lay, f3);
            curr=3;
        } else if (curr == 3) {
            ft.replace(R.id.lay, f1);
            curr=1;
        }
        ft.commit();
    }
}