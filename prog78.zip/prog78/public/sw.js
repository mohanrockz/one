(()=>{
    // install
    self.addEventListener("install",(e)=>{
        console.log("2. Service Worker Installed...",e);
        self.skipWaiting();
    });
    // activate
    self.addEventListener("activate",(e)=>{
        console.log("3. Service Worker Activated...",e);
    });
    // fetch
    self.addEventListener("fetch",(e)=>{
        console.log("4. Service Worker Start Fetching...",e.request.url);
    })
})();

