self.addEventListener('install',event=>

console.log('sw is installed'));

self.addEventListener('active', event=>
console.log('sw is activated'));

self.addEventListener('fetch', event=>
console.log('sw is fetching'));