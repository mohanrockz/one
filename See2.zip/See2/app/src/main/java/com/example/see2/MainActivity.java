package com.example.see2;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.os.Bundle;
import android.widget.CalendarView;
import android.widget.CompoundButton;
import android.widget.ImageButton;
import android.widget.Switch;

public class MainActivity extends AppCompatActivity {

Switch swt;
ImageButton img;
ConstraintLayout cly;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        swt=findViewById(R.id.switch1);
        img=findViewById(R.id.imageButton);
        cly=findViewById(R.id.clay);

        CalendarView cv= new CalendarView(this);

        swt.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked){
                    img.setEnabled(true);
                    cly.addView(cv);

                }else {
                    img.setEnabled(false);
                    cly.removeView(cv);
                }
            }
        });










    }
}